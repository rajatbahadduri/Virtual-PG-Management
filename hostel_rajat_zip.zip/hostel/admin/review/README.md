
# review-page-using-php-oops
Review Page with Sql using Php oops concept.

import reviewsystem.sql in your sql admin page.

copy all files and paste in htdocs
![Screenshot 2023-04-26 135912](https://user-images.githubusercontent.com/106007629/235740277-868d9881-60ae-4d1e-9f05-66075aa37bea.png)
